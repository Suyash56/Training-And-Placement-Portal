from django.contrib import admin
from basic_app.models import Student,Placed_student
# Register your models here.
admin.site.register(Student)
admin.site.register(Placed_student)